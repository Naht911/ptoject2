# Welcome to eProject of group 5 - FPT Aptech - T1.2203.M1

[Click here to see demo site 🔗](/ "Click here to see demo site")

## #What we used ?
- HTML
- CSS
- JavaScript
- [Jquery 🔗](https://jquery.com/ "Jquery")
- [Bootstrap 🔗](https://getbootstrap.com/ "Bootstrap")
- [Lightbox.js 🔗](https://victordiego.com/lightbox/ "Lightbox")
- [Font Awesome 🔗](https://fontawesome.com/ "Font Awesome")
- [Sweetalert2 🔗](https://sweetalert2.github.io/ "Sweetalert2")
- [Notus Angular 🔗](https://www.creative-tim.com/product/notus-angular "Notus Angular") - Special Thanks to [Creative Tim](https://www.creative-tim.com/ "Creative Tim").
- Finally Thanks to [Google.com 🔗](https://www.google.com/ "Google")



